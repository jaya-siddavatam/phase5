function validation() {
    // alert("welcome to validate page");

    var email = document.getElementById("n1").value;
    let password = document.getElementById("n2").value;

    if (email.length == 0) {
        alert("Plz enter email id")
        return false;
    } else if (password.length == 0) {
        alert("plz enter the password")
        return false;
    } else if (email == "jaya@gmail.com" && password == "1234") {
        alert("successfully login")
        return true;
    } else {
        alert("failure try once again")
        return false;
    }

}