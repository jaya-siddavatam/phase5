package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class GooglePageTest {
	  WebDriver wd;
	  @BeforeMethod
	  public void beforeMethod() {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\Downloads\\chromedriver_win32\\chromedriver.exe");
			wd = new ChromeDriver();
		  
		  }
	  @Test
	  public void googlepagetest() {
		  
		  wd.get("https://www.google.com/");
		 // wd.manage().window().fullscreen();
		  wd.manage().window().maximize();
		  //wd.switchTo().alert().accept();
		  //wait 2min until the webdriver will load the tag name q
		  wd.manage().timeouts().implicitlyWait(Duration.ofMinutes(1));
		  WebElement textref = wd.findElement(By.name("q"));
		  textref.sendKeys("What is testing");
		  WebElement submitref = wd.findElement(By.name("btnK"));
		 // submitref.click();

		  submitref.sendKeys(Keys.ENTER);
//  driver.findElement(By.id(“xyz”)).sendKeys(Keys.CONTROL + “t”);
//driver.findElements(By.id(“xyz”).sendKeys(Keys.CONTROL + “w”);
		  
		  try {
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		  wd.navigate().back();
	  }
	
	
	  @AfterMethod
	  public void afterMethod() {
		  
	  }

}
