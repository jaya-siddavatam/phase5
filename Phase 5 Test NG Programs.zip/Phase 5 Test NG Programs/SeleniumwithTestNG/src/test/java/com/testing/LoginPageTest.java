package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class LoginPageTest {
	WebDriver wd;

  @BeforeMethod
  public void beforeMethod() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\Downloads\\chromedriver_win32\\chromedriver.exe");
		wd = new ChromeDriver();
  }
  
  @Test
  public void loginpagetest() {
	  wd.get("http://192.168.43.25:5500/login.html");
		WebElement emailref = wd.findElement(By.id("n1"));
		WebElement passref = wd.findElement(By.id("n2"));
		emailref.sendKeys("jaya@gmail.com");
		passref.sendKeys("1234");
		WebElement submitref = wd.findElement(By.id("b1"));
		submitref.click();
		
		Alert alertref = wd.switchTo().alert();
		
		String result = alertref.getText();
		alertref.accept(); //click ok button in alert box
		assertEquals(result, "successfully login");
	
		
  }

  @AfterMethod
  public void afterMethod() {
	  
	  wd.close();
  }

}
