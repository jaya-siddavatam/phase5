package com.ss;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScreenShots {
	
	 public static void main(String[] args ) throws IOException
	    {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\Downloads\\chromedriver_win32\\chromedriver.exe");
	       WebDriver driver = new ChromeDriver();
	      
	       driver.get("https://www.flipkart.com/");
	       
	       WebElement upload = driver.findElement(By.xpath("//*[@type='text']"));
	       driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(1));
	       upload.click();
	       
	       TakesScreenshot ts = (TakesScreenshot)driver;
	       File scr = ts.getScreenshotAs(OutputType.FILE);
	       FileUtils.copyFile(scr, new File("C:\\Users\\Toshiba\\Pictures/Screenshot/test.png"));
	       System.out.println("ScreenShot taken");
	       
	       
	    }


}
