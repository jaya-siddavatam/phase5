package com.test;

import org.testng.annotations.Test;

public class ScreenShots {

	
}
