package com.service;

import com.bean.Account;
import com.dao.AccountDao;

public class AccountService {
	AccountDao ad = new AccountDao();
	public String createaccount(Account account) {
		
		if(account.getAmount()<500) {
			return "Min Balance must be 500";
		}else if(ad.createaccount(account)>0){
			return "Account created Successfully";
		}else {
			return "Account did not created";
		}	
	}
	public String findbalance(int accno) {
		
		float balanceAmount = ad.findbalance(accno);
		if(balanceAmount>=0) {
			return "Your account balance is "+balanceAmount;
		}if(balanceAmount==-1) {
			return "Account number doesn't exist";
		}else {
			return "Exception generated";
		}
		
	}
	
	public String withdraw(Account account) {
		float balanceAmount = ad.findbalance(account.getAccno());
		
		if(balanceAmount ==-1) {
			return "Invalid account number";
		}
		else if(balanceAmount - account.getAmount() > 500 ) {
			
				if(ad.withdrawn(account)>0) {
					return "Withdrawn done successfully";
				}else {
					return "Didn't withdraw";
				}
		}else {
			return "Your can't withdraw you have to maintain min 500";
		}
	}
	
	public String deposit(Account account) {
		if(account.getAmount()>50000) {
			return "You can't deposite 50000 at time";
		}else if(ad.deposit(account)>0) {
			return "Deposit done successfully";
		}else {
			return "Didn't desosit";
		}
	}
	}