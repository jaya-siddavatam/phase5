package com.service;

import org.testng.annotations.Test;

public class OrderTestExecution {
//test ng will execute in alphabetical order
  @Test(priority = 1)
  public void b() {
	  System.out.println("B test Function");
  }
  
  @Test(priority = 4)
  public void a() {
	  System.out.println("A test Function");
  }
  @Test(priority = 3)
  public void d() {
	  System.out.println("D test Function");
  }
  @Test(priority = 2)
  public void c() {
	  System.out.println("C test Function");
  }
  //if it has same priority then it will check alphabetical order
  @Test(priority = 2)
  public void e() {
	  System.out.println("E test Function");
  }
}
