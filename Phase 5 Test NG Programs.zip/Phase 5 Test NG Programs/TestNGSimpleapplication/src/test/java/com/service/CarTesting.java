package com.service;

import org.testng.annotations.Test;

public class CarTesting {
	  @Test(groups = {"speeds"})
	  public void speed() {
		  System.out.println("Car Speed Testing");
	  }
	  @Test
	  public void colour() {
		  System.out.println("Car colour Testing");
	  }
	  @Test(groups = {"m" ,"speeds"})
	  //mailage is also a part of speed group
	  public void mailage() {
		  System.out.println("Car mailage Testing");
	  }
}
