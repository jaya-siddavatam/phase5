package com.service;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.bean.Account;

public class AccountServiceTest {

  @Test
  public void createaccountTest() {
	  AccountService ac = new AccountService();
	  Account acc1 = new Account(100,"jaya",400);
	  String result = ac.createaccount(acc1);
	  assertEquals(result, "Min Balance must be 500");
//	  
//	  Account acc2 = new Account(102,"jaya",17000);
//	  String result2 = ac.createaccount(acc2);
//	  assertEquals(result2, "Account created Successfully");
	  
//	  Account acc3 = new Account(100,"jaya",7000); //account no pk
//	  String result3 = ac.createaccount(acc3);
//	  assertEquals(result3, "Account did not created");
	  
	  
  }

  @Test
  //@Ignore
  public void depositTest() {
    //throw new RuntimeException("Test not implemented");
	  AccountService ac = new AccountService();
	  Account acc1 = new Account();
	  acc1.setAccno(100);
	  acc1.setAmount(15000);
	  
	  String result1 = ac.deposit(acc1);
	  assertEquals(result1, "Deposit done successfully");
	  
	  Account acc2 = new Account();
	  acc2.setAccno(100);
	  acc2.setAmount(55000);
	  String result2 = ac.deposit(acc2);
	  assertEquals(result2, "You can't deposite 50000 at time");
  }

  @Test
  //@Ignore
  public void findbalanceTest() {
   // throw new RuntimeException("Test not implemented");
	  AccountService as = new AccountService();
	  
	  String balanceDetails1 = as.findbalance(100);
	  String balanceDetails2 = as.findbalance(102);
	  String balanceDetails3 = as.findbalance(1000);
	  assertEquals(balanceDetails1, "Your account balance is 700.0");
	  assertEquals(balanceDetails2, "Your account balance is 17000.0");
	  assertEquals(balanceDetails3, "Account number doesn't exist");
  }

  @Test
  //@Ignore
  public void withdrawTest() {
	  //throw new RuntimeException("Test not implemented");
	  AccountService ac = new AccountService();
	 
	  
//	  Account acc1 = new Account();
//	  acc1.setAccno(100);
//	  acc1.setAmount(199);
//	  String result1 = ac.withdrawn(acc1);
//	  assertEquals(result1, "Withdrawn done successfully");
	  
//	  Account acc2 = new Account();
//	  acc2.setAccno(1000);
//	  acc2.setAmount(100);
//	  String result2 = ac.withdrawn(acc2);
//	  assertEquals(result2, "Invalid account number");
//	  
	  Account acc3 = new Account();
	  acc3.setAccno(102);
	  acc3.setAmount(5000);
	  String result3 = ac.withdraw(acc3);
	  assertEquals(result3, "Your can't withdraw you have to maintain min 500");
  }
}
