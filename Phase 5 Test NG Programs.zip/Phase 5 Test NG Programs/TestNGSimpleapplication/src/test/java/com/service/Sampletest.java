package com.service;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Sampletest {
  @Test
  public void f1() {
	  System.out.println("1st method 2nd classs");
  }
  @Test
  public void f2() {
	  System.out.println("2nd method 2nd classs");
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Before method 2nd class");
  }
  @AfterMethod
  public void afterMethod() {
	  System.out.println("After method 2nd class");
  
  }
  @BeforeClass
  public void beforeClass() {
	  System.out.println("Before class 2nd class");
  }
  @AfterClass
  public void afterClass() {
	  System.out.println("After class 2nd class");
  }

}
