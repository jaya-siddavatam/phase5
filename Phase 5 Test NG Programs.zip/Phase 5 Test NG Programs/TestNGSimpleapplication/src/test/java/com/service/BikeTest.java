package com.service;

import org.testng.annotations.Test;

public class BikeTest {
  @Test(groups = {"speeds"}) 
  public void speed() {
	  System.out.println("Bike Speed Testing");
  }
  @Test
  public void colour() {
	  System.out.println("Bike colour Testing");
  }
  @Test(groups = {"m"})
  public void mailage() {
	  System.out.println("Bike mailage Testing");
  }
}
