package com;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://192.168.43.25:5500/login.html");
		
//		WebElement emailref = wd.findElement(By.id("n1"));
//		WebElement passref = wd.findElement(By.id("n2"));
//		emailref.sendKeys("jaya@gmail.com");
//		passref.sendKeys("1234");
//		WebElement submitref = wd.findElement(By.id("b1"));
//		submitref.click();
//		
//		String pagepath = wd.getCurrentUrl();
//		System.out.println(pagepath);
//		
//		WebElement h1ref = wd.findElement(By.tagName("h1"));
//		//System.out.println(h1ref);
//		System.out.println(h1ref.getText());
//		
////		WebElement resetref = wd.findElement(By.id("b2"));
////		resetref.click();
		
		
//		//email validation
//		WebElement emailref = wd.findElement(By.id("n1"));
//		WebElement passref = wd.findElement(By.id("n2"));
//		WebElement submitref = wd.findElement(By.id("b1"));
//		submitref.click();
//
//		//alert box reference
//		Alert alertref = wd.switchTo().alert();
//		//gives the content of alert box 
//		System.out.println(alertref.getText());
//		//click ok button in alert box
//		alertref.accept();
//		wd.close();
		
		
//		//password validation
//		WebElement emailref = wd.findElement(By.id("n1"));
//		WebElement passref = wd.findElement(By.id("n2"));
//		emailref.sendKeys("jaya@gmail.com");
//		WebElement submitref = wd.findElement(By.id("b1"));
//		submitref.click();
//		//alert box reference
//		Alert alertref = wd.switchTo().alert();
//		//gives the content of alert box 
//		System.out.println(alertref.getText());
//		//click ok button in alert box
//		alertref.accept();
//		wd.close();
		
		//password validation
		WebElement emailref = wd.findElement(By.id("n1"));
		WebElement passref = wd.findElement(By.id("n2"));
		emailref.sendKeys("jaya@gmail.com");
		passref.sendKeys("1234");
		WebElement submitref = wd.findElement(By.id("b1"));
		submitref.click();
		//alert box reference
		Alert alertref = wd.switchTo().alert();
		//gives the content of alert box 
		System.out.println(alertref.getText());
		//click ok button in alert box
		alertref.accept();
		WebElement h1ref = wd.findElement(By.tagName("h1"));
		System.out.println(h1ref.getText());
		wd.close();
		
	}
}