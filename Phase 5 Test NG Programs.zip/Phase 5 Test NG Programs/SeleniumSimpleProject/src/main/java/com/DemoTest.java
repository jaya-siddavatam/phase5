package com;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoTest {
//here we are testing the webpage
	public static void main(String[] args) {
		//we are giving the path of chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("file:///C:/Users/Toshiba/Desktop/Git%20Hub%20repository/Phase%205%20Test%20NG%20Programs/index.html");
		//url to run static or dynamic webpage
		
//		String titletagcontent = wd.getTitle();
//		System.out.println(titletagcontent);
//		
//		String url =wd.getCurrentUrl();
//		System.out.println(url);
//		
//		String pagecontent = wd.getPageSource();
//		System.out.println(pagecontent);
		
		//findelement return type is webelement
		
		WebElement h2tag = wd.findElement(By.tagName("h1"));
		System.out.println("Tag name is  "+h2tag.getTagName()+"\n and text inside is  "+h2tag.getText());
		
		WebElement pTagRef	 = wd.findElement(By.tagName("p"));
		WebElement divTagRef = wd.findElement(By.tagName("div"));
		System.out.println(pTagRef.getTagName()+" = "+pTagRef.getText());
		System.out.println(divTagRef.getTagName()+" = "+divTagRef.getText());
		
		List<WebElement> listOfPTag = wd.findElements(By.tagName("p"));
		
		Iterator<WebElement> ii = listOfPTag.iterator();
		
		while(ii.hasNext()) {
			
			WebElement ww = ii.next();
			
			System.out.println(ww.getTagName()+" "+ww.getText());
		}
		
		WebElement divTagUsingIdRef = wd.findElement(By.id("d1"));
		System.out.println(divTagUsingIdRef.getTagName()+" "+divTagUsingIdRef.getText());
	
		
		wd.close();
		
	
	
	}

}
